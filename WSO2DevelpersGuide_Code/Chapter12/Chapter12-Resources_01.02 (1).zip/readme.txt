In this chapter resources you can find:

- workspace: folder with the Eclipse workspace of this chapter
- carbonApp: folder with carbon files ready to deploy. You can build this carbon file from the workspace
- axis2.xml: sample of axi2.xml file configured properly for using JMS in this chapter
- jndi.properties: sample of jndi.properties for this chapter 
- Chapter12-JMS-Publisher&Consumer-soapui-project.xml: SoapUI project for testing the proxy that insert messages in the queue